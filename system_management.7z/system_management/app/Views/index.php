<?= $this->extend("layouts/default")?>
<?= $this->section("title")?>Manage BIR<?= $this->endSection() ?>

<?= $this->section("content")?>
<p>Welcome</p>
<?= $this->endSection()?>